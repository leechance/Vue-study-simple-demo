跟着慕课网学习项目

Vuex,Vue-router的基本应用

https://www.imooc.com/video/18563


