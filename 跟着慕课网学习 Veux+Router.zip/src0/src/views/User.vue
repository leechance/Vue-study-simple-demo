<template>
	<div>
		<div class="btn" @click="add()">添加</div>
		<p>User</p>
	</div>
</template>

<script>
	export default {
		name:"User",
		methods:{
			add(){
			this.$router.push('/add')
				
			}
		}
	}
</script>

<style>
</style>
