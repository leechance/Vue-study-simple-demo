export const ENDED = 'ended'
export const LIVE = 'live'
export const CONCERN = 'concern'
export const DEMO = 'demo'
